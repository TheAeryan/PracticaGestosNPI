var class_accion_gesto_zoom =
[
    [ "AccionGestoZoom", "class_accion_gesto_zoom.html#af5ec64ff1b7cf3d017c5b0fd6e6795a0", null ],
    [ "continuarGesto", "class_accion_gesto_zoom.html#a10dad9083cbb468f5cb2b15f8d637290", null ]
];