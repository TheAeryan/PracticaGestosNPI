var class_mano =
[
    [ "Mano", "class_mano.html#af81c61ced8b2d12eb3209bd3922a2ffa", null ],
    [ "getEstado", "class_mano.html#a8e75b239c993fde03899405bf083fd91", null ],
    [ "getPos", "class_mano.html#a4763b0128cd2822767b3e29dada969c1", null ],
    [ "getX", "class_mano.html#a71db9f7cf99cd33f46de76e428c0d627", null ],
    [ "getY", "class_mano.html#add65e400e3ccd21c78bb0e699bbdaeed", null ],
    [ "getZ", "class_mano.html#af04d090beb69e4b7e6f6408abb20a27f", null ],
    [ "setEstado", "class_mano.html#a27b4befb030264cde8a8824a4a318193", null ],
    [ "setPos", "class_mano.html#a8eb713a5f0435d0b1266f272b4742dec", null ],
    [ "setXYZ", "class_mano.html#ac1e1062a8ca8480426805a94f26fa23d", null ]
];