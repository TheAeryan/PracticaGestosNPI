var class_accion_gesto_rotar =
[
    [ "AccionGestoRotar", "class_accion_gesto_rotar.html#a3bd27ff7bbf1106f20ac276a0fb06e40", null ],
    [ "continuarGesto", "class_accion_gesto_rotar.html#a48dada492c02f94b9f943f29d6d26cf9", null ]
];