var files_dup =
[
    [ "ApiGestos.h", "_api_gestos_8h_source.html", null ],
    [ "BodyBasics.h", "_body_basics_8h_source.html", null ],
    [ "model3D.h", "model3_d_8h_source.html", null ],
    [ "resource.h", "resource_8h_source.html", null ]
];