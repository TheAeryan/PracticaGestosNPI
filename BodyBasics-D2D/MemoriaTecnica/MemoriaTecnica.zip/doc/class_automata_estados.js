var class_automata_estados =
[
    [ "AutomataEstados", "class_automata_estados.html#a8df7ab0fea64e0ea3852e0e74b5899f8", null ],
    [ "getEstado", "class_automata_estados.html#a199a49240f9df301d403a33a125479a5", null ],
    [ "transicionEstado", "class_automata_estados.html#ab8033acac960108ee0b76d104ec4bf0e", null ]
];