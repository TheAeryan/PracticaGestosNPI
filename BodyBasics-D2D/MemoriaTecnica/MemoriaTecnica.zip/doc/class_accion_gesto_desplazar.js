var class_accion_gesto_desplazar =
[
    [ "AccionGestoDesplazar", "class_accion_gesto_desplazar.html#adf76ef14f700a51b49dd18efaa9152e1", null ],
    [ "continuarGesto", "class_accion_gesto_desplazar.html#aac5ef84d8e2778401fb49e6dd158d179", null ]
];