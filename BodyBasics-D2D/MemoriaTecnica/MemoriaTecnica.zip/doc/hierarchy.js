var hierarchy =
[
    [ "AccionGesto", "class_accion_gesto.html", [
      [ "AccionGestoCambiarAnio", "class_accion_gesto_cambiar_anio.html", null ],
      [ "AccionGestoDesplazar", "class_accion_gesto_desplazar.html", null ],
      [ "AccionGestoRotar", "class_accion_gesto_rotar.html", null ],
      [ "AccionGestoZoom", "class_accion_gesto_zoom.html", null ]
    ] ],
    [ "AutomataEstados", "class_automata_estados.html", null ],
    [ "CBodyBasics", "class_c_body_basics.html", null ],
    [ "Mano", "class_mano.html", null ],
    [ "model3D", "classmodel3_d.html", null ]
];