var annotated_dup =
[
    [ "AccionGesto", "class_accion_gesto.html", "class_accion_gesto" ],
    [ "AccionGestoCambiarAnio", "class_accion_gesto_cambiar_anio.html", "class_accion_gesto_cambiar_anio" ],
    [ "AccionGestoDesplazar", "class_accion_gesto_desplazar.html", "class_accion_gesto_desplazar" ],
    [ "AccionGestoRotar", "class_accion_gesto_rotar.html", "class_accion_gesto_rotar" ],
    [ "AccionGestoZoom", "class_accion_gesto_zoom.html", "class_accion_gesto_zoom" ],
    [ "AutomataEstados", "class_automata_estados.html", "class_automata_estados" ],
    [ "CBodyBasics", "class_c_body_basics.html", "class_c_body_basics" ],
    [ "Mano", "class_mano.html", "class_mano" ],
    [ "model3D", "classmodel3_d.html", "classmodel3_d" ]
];