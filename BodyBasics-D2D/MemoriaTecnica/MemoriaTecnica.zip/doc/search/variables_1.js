var searchData=
[
  ['mano_5fder_77',['mano_der',['../class_accion_gesto.html#af0ac418aa4067d411b42bd3cc1381581',1,'AccionGesto']]],
  ['mano_5fizd_78',['mano_izd',['../class_accion_gesto.html#ab909b1a24ac564d84eec7d8431b2f5cc',1,'AccionGesto']]]
];
