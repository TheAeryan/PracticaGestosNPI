var indexSectionsWithContent =
{
  0: "acdgimrstz~",
  1: "acm",
  2: "acdgmrstz~",
  3: "im"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Funciones",
  3: "Variables"
};

