var searchData=
[
  ['setcolor_69',['setColor',['../classmodel3_d.html#a1d4a849151f39e51d71358a74da68705',1,'model3D']]],
  ['setestado_70',['setEstado',['../class_mano.html#a27b4befb030264cde8a8824a4a318193',1,'Mano']]],
  ['setpos_71',['setPos',['../class_mano.html#a8eb713a5f0435d0b1266f272b4742dec',1,'Mano']]],
  ['setxyz_72',['setXYZ',['../class_mano.html#ac1e1062a8ca8480426805a94f26fa23d',1,'Mano']]]
];
