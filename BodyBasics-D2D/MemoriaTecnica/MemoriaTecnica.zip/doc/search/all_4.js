var searchData=
[
  ['interfaz_5fgrafica_20',['interfaz_grafica',['../class_accion_gesto.html#af05ac5528063cd7ee8c03f6244eac0c9',1,'AccionGesto::interfaz_grafica()'],['../class_c_body_basics.html#a033b93e2ff837ca0f30bf9d593c71c2c',1,'CBodyBasics::interfaz_grafica()']]]
];
