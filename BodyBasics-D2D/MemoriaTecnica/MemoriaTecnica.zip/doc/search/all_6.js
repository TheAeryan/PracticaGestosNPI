var searchData=
[
  ['rotar_26',['rotar',['../classmodel3_d.html#ae34aea5f75cabc5ffd0d00a7bdce4ad3',1,'model3D']]],
  ['run_27',['Run',['../class_c_body_basics.html#a323805eb1adec3542251b2b32b0fe46e',1,'CBodyBasics']]]
];
