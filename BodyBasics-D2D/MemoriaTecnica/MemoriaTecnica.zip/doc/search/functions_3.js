var searchData=
[
  ['getestado_59',['getEstado',['../class_mano.html#a8e75b239c993fde03899405bf083fd91',1,'Mano::getEstado()'],['../class_automata_estados.html#a199a49240f9df301d403a33a125479a5',1,'AutomataEstados::getEstado()']]],
  ['getpos_60',['getPos',['../class_mano.html#a4763b0128cd2822767b3e29dada969c1',1,'Mano']]],
  ['getx_61',['getX',['../class_mano.html#a71db9f7cf99cd33f46de76e428c0d627',1,'Mano']]],
  ['gety_62',['getY',['../class_mano.html#add65e400e3ccd21c78bb0e699bbdaeed',1,'Mano']]],
  ['getz_63',['getZ',['../class_mano.html#af04d090beb69e4b7e6f6408abb20a27f',1,'Mano']]]
];
