var classmodel3_d =
[
    [ "model3D", "classmodel3_d.html#af46a766c72d634f9b5a8934774b7b848", null ],
    [ "cambiarAnio", "classmodel3_d.html#a82735f590ee902179375cd4e07a16bb9", null ],
    [ "desplazar", "classmodel3_d.html#aac896fd19ed57a6ae5dc678a6f9a2fd8", null ],
    [ "display", "classmodel3_d.html#a2dae555437f373f2e0dd391410cffce3", null ],
    [ "drawLineaTemporal", "classmodel3_d.html#ad588fb021e322a9ef72dac832c5799f3", null ],
    [ "drawMarcaTemporal", "classmodel3_d.html#af1f4916cccd8f156a8d8b2d4d1443bc8", null ],
    [ "drawObject", "classmodel3_d.html#a5fd407e1ea744032ab295cf2f1273f8b", null ],
    [ "rotar", "classmodel3_d.html#ae34aea5f75cabc5ffd0d00a7bdce4ad3", null ],
    [ "setColor", "classmodel3_d.html#a1d4a849151f39e51d71358a74da68705", null ],
    [ "zoom", "classmodel3_d.html#a02f5f118be3f4546f7bc498a16e2cf56", null ]
];