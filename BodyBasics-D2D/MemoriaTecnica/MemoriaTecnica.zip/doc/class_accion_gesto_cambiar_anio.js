var class_accion_gesto_cambiar_anio =
[
    [ "AccionGestoCambiarAnio", "class_accion_gesto_cambiar_anio.html#a0953628e527fb88f510a044e28f21bbf", null ],
    [ "continuarGesto", "class_accion_gesto_cambiar_anio.html#a6933acc946815600a7864a9eb152e81d", null ]
];