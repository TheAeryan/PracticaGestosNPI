var class_c_body_basics =
[
    [ "CBodyBasics", "class_c_body_basics.html#aa8145b6eb33ac88a001df4068052529d", null ],
    [ "~CBodyBasics", "class_c_body_basics.html#abf815c639b2e4c7e256411b6fbd01d79", null ],
    [ "DlgProc", "class_c_body_basics.html#a2fbdc1715b6f59cad701be7b5a0b89c6", null ],
    [ "Run", "class_c_body_basics.html#a323805eb1adec3542251b2b32b0fe46e", null ],
    [ "interfaz_grafica", "class_c_body_basics.html#a033b93e2ff837ca0f30bf9d593c71c2c", null ]
];