var class_accion_gesto =
[
    [ "AccionGesto", "class_accion_gesto.html#adf19ff93c73ebfc11ed5d8f21293bda8", null ],
    [ "AccionGesto", "class_accion_gesto.html#a0129d5325379db2eb072b69f6bbcda8c", null ],
    [ "continuarGesto", "class_accion_gesto.html#a8036c095d46ed654f1b5fea69a1a7f93", null ],
    [ "interfaz_grafica", "class_accion_gesto.html#af05ac5528063cd7ee8c03f6244eac0c9", null ],
    [ "mano_der", "class_accion_gesto.html#af0ac418aa4067d411b42bd3cc1381581", null ],
    [ "mano_izd", "class_accion_gesto.html#ab909b1a24ac564d84eec7d8431b2f5cc", null ]
];